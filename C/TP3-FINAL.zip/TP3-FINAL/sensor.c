#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
#include <unistd.h>

typedef struct
{
    int process;
    int temperature;
}t_info;

int main(int argc, char *argv[])
{
  FILE *file1;
  t_info data;
  int fifo_centralizador;
  int max= 45;
  int min= 0;
  char * fifo_route = "/tmp/fifo_centralizador";
  int temperature =1;
  int c=0;
  // while ((c = getopt(argc, argv, "n")) != -1) {
  //   switch (c) {
  //     case n: printf("El numero de sensor es %d\n",n );
  //   }
  //
  // }
  fifo_centralizador=open(fifo_route,O_RDWR);
  if(fifo_centralizador < 0) {
    printf("Error in opening FIFO");
    exit(-1);
  }
  data.process = getpid();
  while(1){
   sleep(2);
   data.temperature = (rand() % (max + 1 - min)) + min;
   write(fifo_centralizador,&data,sizeof(t_info));
   printf("temperatura %d proceso %d\n",data.temperature,data.process );
  }
  close(fifo_centralizador);
  return 0;
}
