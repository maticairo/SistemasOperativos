#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#define MAX_SENSORS_ALLOWED 10

typedef struct
{
    int process;
    int temperature;
}t_info_received;

typedef struct
{
  int pid;
  int acum;
	int maxTemperature;
	int minTemperature;
	int cantTemperatures;
}t_sensor_info;

float calculateAverage(int);

main()
{
	int file1;
	int fifo_centralizador;
	char * fifo_route = "/tmp/fifo_centralizador";
	int temperature = 0;
	t_info_received data;
	fifo_centralizador = open(fifo_route ,O_RDWR);
	t_sensor_info processes[MAX_SENSORS_ALLOWED];
  int lastProcess =0;
  int newProcess =0;

	if(fifo_centralizador<1) {
		printf("Error opening file");
		file1 = mkfifo(fifo_route,0666);

		if(file1<0) {
		 printf("Unable to create a fifo");
		 exit(-1);
		}
		printf("fifo_centralizador creado correctamente");
	}

	while(1){

		read(fifo_centralizador,&data,sizeof(t_info_received));
    if(data.temperature != 0){
      newProcess =1;
  		for(int i=0;i< MAX_SENSORS_ALLOWED; i++){
        if(processes[i].pid == data.process){
          newProcess=0;
          processes[i].acum += data.temperature;
          processes[i].cantTemperatures ++;
          // printf("cantidad %d",processes[i].cantTemperatures);
          if(processes[i].cantTemperatures >= 10){
            float promedio = calculateAverage(processes[i].acum);
            processes[i].cantTemperatures = 0;
            processes[i].acum = 0;
            printf("Promedio de las ultimas 10 temperaturas para el proceso %d: %2f grados\n",processes[i].pid, promedio);
          }
          //actualizo las temperaturas
          if(processes[i].maxTemperature < data.temperature){
            processes[i].maxTemperature = data.temperature;
            printf("NUEVA temperatura MAXIMA %d para el proceso %d\n", processes[i].maxTemperature, processes[i].pid  );
          }

          if(processes[i].minTemperature == 0){
            processes[i].minTemperature = 45;
          }

          if(processes[i].minTemperature > data.temperature){
            processes[i].minTemperature = data.temperature;
            printf("NUEVA temperatura MINIMA %d para el proceso %d\n", processes[i].minTemperature, processes[i].pid);
          }

        }
  		}
      if(newProcess){
        processes[lastProcess].pid = data.process;
        printf("nuevo sensor %d \n", processes[lastProcess].pid);
        newProcess = 0;
        lastProcess ++;
      }
    }
	}

	close(fifo_centralizador);
	return 0;
}

float calculateAverage(int acum){
  return acum / 10;
}
