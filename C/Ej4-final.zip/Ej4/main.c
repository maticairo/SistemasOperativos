#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <wait.h>
#include <semaphore.h>
#include <signal.h>
#include <time.h>

void miHandler(int a);
void ProcesoB();
void ProcesoA(pid_t pidHijo,char * archivoALeer);
int isLetterOrNumber(char c);
void desordenarYGrabarEnArchivo(char *cad,FILE * pr);
void verificarUltimaLinea();

int terminarProc = 0;

int main(int argc,char **argv)
{
    pid_t pidHijo;
    if(argc !=2)
    {
        printf("Debe pasar el nombre del archivo a leer");
        exit(1);
    }
    pidHijo = fork();
    if(pidHijo==0)
    {
        ProcesoB(); ///HIJO
    }
    else
    {
        ProcesoA(pidHijo,argv[1]);
    }
    return 0;
}

void miHandler(int a)
{
    terminarProc = 1;

}

void ProcesoB()  ///LEER MC Y GENERAR ARCH DESORDENADO
{
    FILE * pr;
    int fd = shm_open("mimemoria",O_CREAT|O_RDONLY,0);
    ftruncate(fd,600);
    char * memoria = mmap(NULL,600,PROT_READ,MAP_SHARED,fd,0);
    close(fd);
    struct sigaction handler;
    handler.sa_handler=miHandler;
    sigaction(SIGUSR1,&handler,NULL);
    sem_t * s1 = sem_open("turnoPadre",O_CREAT,0600,1);
    sem_t * s2 = sem_open("msjEnBuffer",O_CREAT,0600,0);
    pr=fopen("archdesordenado","r+");
    if(!pr)
    {
        printf("\nEl archivo no se pudo abrir");
        exit(1);
    }
    while(terminarProc == 0)
    {
        sem_wait(s2); ///P(S2)
        desordenarYGrabarEnArchivo(memoria,pr);
        sem_post(s1); ///V(S1)
    }
    fclose(pr);
    verificarUltimaLinea();
    sem_close(s1);
    sem_close(s2);
    sem_unlink("turnoPadre");
    sem_unlink("msjEnBuffer");
    munmap(memoria,600);
    shm_unlink("mimemoria");
}


void ProcesoA(pid_t pidHijo,char * archivoALeer)  ///MANDAR ARCHIVO A MC
{
    FILE * pf,* pr;
    char linea[500];
    int fd = shm_open("mimemoria",O_CREAT|O_RDWR,S_IRUSR|S_IWUSR);
    ftruncate(fd,600);
    char * memoria = mmap(NULL,600,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    close(fd);
    sem_t * s1 = sem_open("turnoPadre",O_CREAT,0600,1);
    sem_t * s2 = sem_open("msjEnBuffer",O_CREAT,0600,0); ///INICIALIZO EN 0 PORQUE NO HAY NINGUN MSJ
    pf=fopen(archivoALeer,"rt");
    if(!pf)
    {
        printf("\nEl archivo no existe");
        exit(1);
    }
    pr=fopen("archdesordenado","wt");
    if(!pr)
    {
        printf("\nEl archivo no se pudo crear");
        exit(2);
    }
    fclose(pr);
    while(fgets(linea,sizeof(linea),pf))
    {
        sem_wait(s1); ///P(S1)
        strcpy(memoria,linea);
        sem_post(s2); ///V(S2)
    }
    sem_wait(s1);
    fclose(pf);
    kill(pidHijo,10); ///MANDO SIGUSR1 AL HIJO
    sem_post(s2);
    wait(NULL);
    sem_close(s1);
    sem_close(s2);
    sem_unlink("turnoPadre");
    sem_unlink("msjEnBuffer");
    munmap(memoria,600);
    shm_unlink("mimemoria");
}

void verificarUltimaLinea()
{
    FILE * pr=fopen("archdesordenado","r+");
    if(!pr)
    {
        printf("\nEl archivo no se pudo abrir");
        exit(1);
    }
    char linea[500];
    char ultimalinea[500];
    char anteultimalinea[500];
    int nreg = 0;
    int anteultimoreg;
    while(fgets(linea,sizeof(linea),pr))
    {
        nreg++;
    }
    strcpy(ultimalinea,linea);
    fseek(pr,0L,0);
    anteultimoreg = nreg-1;
    int regleido=1;
    while(fgets(linea,sizeof(linea),pr) && regleido!=anteultimoreg)
    {
        regleido++;
    }
    strcpy(anteultimalinea,linea);
    if(strcmp(anteultimalinea,ultimalinea)==0)
    {
        fseek(pr,-sizeof(ultimalinea),1);
        fprintf(pr,"                                                                   ");
    }
    fclose(pr);
}

int isLetterOrNumber(char c)
{
    return (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') || ('0' <= c && c <= '9'));
}

void desordenarYGrabarEnArchivo(char *cad, FILE * pr)
{
    srand(time(0)); ///Hace al aleatorio dependiente del tiempo en que inicia la ejecución

    int largo = strlen(cad);
    int i = 0;
    int cantPalabras = 0;
    int cantPalabrasProcesadas = 0;
    char *palabras[100];

    while(i < largo)
    {
        char *str;
        int inicioPalabra = -1, largoPalabra = 0, j;

        while(i < largo && isLetterOrNumber(*(cad+i)))
        {
            if(inicioPalabra == -1)
                inicioPalabra = i;
            i++;
            largoPalabra++;
        }

        if(largoPalabra > 0)
        {
            str = (char*)malloc((largoPalabra+1)*sizeof(char));

            for(j=inicioPalabra; j<i; j++)
                *(str+j-inicioPalabra) = *(cad+j);

            *(str+largoPalabra) = '\0';

            palabras[cantPalabras] = str;

            cantPalabras++;
        }

        while(i < largo && !isLetterOrNumber(*(cad+i)))
            i++;
    }

    while(cantPalabrasProcesadas < cantPalabras)
    {
        int pos = rand()%cantPalabras;
        if(strcmp(palabras[pos],"") !=0)
        {
            fprintf(pr,"%s ",palabras[pos]);
            //puts(palabras[pos]);
            palabras[pos] = "";
            cantPalabrasProcesadas++;
        }
    }
    fprintf(pr,"\n"); ///Grabo el salto de linea
}
