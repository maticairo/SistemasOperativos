#include <sys/types.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>

typedef struct{

  int cantidad_ceros_hallados;
  int cantidad_unos_hallados;
  unsigned int TID;

} t_datos;


void *inicializarMatriz(int *);
void *funcion_thread(void *);


///Declaro las variables globales que van a ser vistas/accedidas por todos los hilos

int *mat; ///Va a ser una matriz dinamica ya que no conozco sus tamaños (fil, col) aca, recien van a ser conocidas en el main
int columnas;
int fi_desde;
int fi_hasta;
FILE *archivo_resultado; ///Archivo donde voy a almacenar los resultados de cada thread



int main(int argc, char *argv[]) {

  if (argc != 4) {
    printf("Error al ingresar parametros, compruebe nuevamente su ingreso; Por ejemplo intente: ./Ej2 9 3 3\n");
    exit(1);
  }
  srand (time(NULL));

  int fi= atoi(argv[1]); ///cant de filas
  int col= atoi(argv[2]); ///cant de col
  int p= atoi(argv[3]); ///nivel paralelismo (cant threads)

///VALIDACION DE PARAMETROS INGRESADOS POR TECLADO
if( fi == 0 || col == 0 || p == 0){
    printf("Los parametros ingresados deben ser numeros > 0\n");
    exit(2);
}

if( fi < 0 || col < 0 || p < 0){
    printf("No se pueden ingresar parametros negativos\n");
    exit(3);
}

if (p > fi) {
    printf("Error al ingresar cantidad de threads: La cantidad de threads debe ser menor que la cantidad de filas de la matriz.\n");
    exit(3);
  }



  mat =(int *)malloc(sizeof(int)*fi*col); ///inicializo la mat dinamica

  t_datos vec[fi];

  columnas=col;
  int i=0;
  int j=0;

///genero la matriz
  for (i = 0; i < fi; i++) {
    for (j = 0; j < col; j++) {
      *(mat+i*j+j)=rand() % 2;
    }
  }


///muestro la matriz
   printf("\nMatriz generada aleatoriamente:\n\n");
   for(i=0; i<fi; i++) {
       for(j=0; j<col; j++)
           printf("%d\t", *(mat + i*j + j));

      printf("\n");
   }


///Ademas la guardo en un archivo
FILE *f = fopen("matriz.txt", "w");
  if (f == NULL){
      printf("Error al abrir el arhivo\n");
      exit(1);
  }
for (i = 0; i < fi; i++) {
  for (j = 0; j < col; j++) {
    fprintf(f, "%d ", *(mat+i*j+j));
  }
  fprintf(f, "\n");
}
fclose(f);

  ///Resolver como hacer cuando da un numero decimal

  int x=fi/p; ///Hallo x equitativas filas para asignarle a cada thread

  fi_desde=0;
  fi_hasta=x;

  pthread_t hilo[p];


  archivo_resultado=fopen("archivo_resultado.bin","wb"); ///Abro el arch donde se va a almacenar todo lo que los threads vayan procesando luego
  if(archivo_resultado == NULL){
   perror("No se puede abrir archivo_resultado.bin");
   return -1;
  }

///For para crear tantos threads como P (nivel paralelismo) se haya recibido
  int k = 0;

  for(k = 0; k < p; k++){

    if(k == p-1){
        if(fi % p != 0) ///Se resuelve el problema de si no son multiplos la cantidad de filas y threads
            fi_hasta += (fi%p);
      }

      int dev;
      dev = pthread_create(&hilo[k],NULL,funcion_thread,archivo_resultado); ///Creo el hilo, donde le paso el hilo, la funcion que va a ejecutar y los parametros que recibe dicha funcion
                                                                      /// en este caso "funcion_thread" recibe un archivo donde va a almacenar los resultados que cada thread procese
      if (dev){
          printf("Error al crear el thread: %d\n", dev);
          exit(-1);
        }
      sleep(1);

      fi_desde=fi_hasta;
      fi_hasta+=x;
  }
  fclose(archivo_resultado);

  for (k = 0; k < p; k++) {
    pthread_join(hilo[k],NULL);
  }

  free(mat); ///libero mem de la matriz dinamica
  FILE *pf;
  pf=fopen("archivo_resultado.bin","rb");
  if (pf==NULL){
   perror("No se puede abrir archivo_resultado.bin");
   return -1;
  }


  ///Leo el archivo donde almacene los calculos de los threads
  i=0;
  fread(&vec[i],sizeof(t_datos),1,pf);
  while (!feof(pf)) {
    i++;
    fread(&vec[i],sizeof(t_datos),1,pf);
  }
  fclose(pf);



  int cantidad_unos_hallados=0;
  int cantidad_ceros_hallados=0;
  int tid_max_ceros;///TID que encontro mayor cant ceros
  int tid_max_unos; ///TID
  int tid_min_ceros; ///TID
  int tid_min_unos; ///TID
  int fila_mayor_ceros=0;  ///fila con mayor cant ceros
  int fila_mayor_unos=0;
  int fila_menor_ceros=0;
  int fila_menor_unos=0;

///Almaceno en variables locales (para luego mostrarla) la info que obtengo del archivo (la cual esta almacenada en un vec de t_datos)
  tid_max_unos=vec[0].cantidad_unos_hallados;
  tid_max_ceros=vec[0].cantidad_ceros_hallados;
  tid_min_ceros=vec[0].cantidad_ceros_hallados;
  tid_min_unos=vec[0].cantidad_unos_hallados;





  ///*****Muestro por info recolectada de CADA FILA************



    printf("NºFila    TID                      Ceros                            Unos\n");
  for (i = 0; i < fi; i++) {
    printf("%d      %d                     %d                                %d\n",i+1,vec[i].TID,vec[i].cantidad_ceros_hallados,vec[i].cantidad_unos_hallados);



    ///acumulo TOTAL de 1 hallados
    cantidad_ceros_hallados+=vec[i].cantidad_ceros_hallados;
    cantidad_unos_hallados+=vec[i].cantidad_unos_hallados;

    if (vec[i].cantidad_ceros_hallados>tid_max_ceros) {
      tid_max_ceros=vec[i].cantidad_ceros_hallados;
      fila_mayor_ceros=i;
    }
    if (vec[i].cantidad_unos_hallados>tid_max_unos) {
      tid_max_unos=vec[i].cantidad_unos_hallados;
      fila_mayor_unos=i;
    }
    if (vec[i].cantidad_ceros_hallados<tid_min_ceros) {
      tid_min_ceros=vec[i].cantidad_ceros_hallados;
      fila_menor_ceros=i;
    }
    if (vec[i].cantidad_unos_hallados<tid_min_unos) {
      tid_min_unos=vec[i].cantidad_unos_hallados;
      fila_menor_unos=i;
    }
  }

      printf("\n*************Datos encontrados**********************\n\n");
      printf("*Cantidad TOTAL de ceros: %d\n", cantidad_ceros_hallados );
      printf("*Cantidad TOTAL de unos: %d\n", cantidad_unos_hallados);
      int filas_max_cant_ceros[fi];
      int filas_max_cant_unos[fi];


///SE HALLAN LA MAYOR CANTIDAD DE 0
      int repetidos_may_cant_ceros=0;
      int cant_elementos_tid_empate_may_cant_ceros=0;
      unsigned int tid_mayor_ceros_empate[p];
      tid_mayor_ceros_empate[cant_elementos_tid_empate_may_cant_ceros]=1;/// se lo inicia con algun valor al azar, para que no tenga TIDs duplicados
      for ( i = 0; i < fi; i++) {
        if (tid_max_ceros==vec[i].cantidad_ceros_hallados) {
          filas_max_cant_ceros[repetidos_may_cant_ceros]=i;
          repetidos_may_cant_ceros++;

          if (tid_mayor_ceros_empate[cant_elementos_tid_empate_may_cant_ceros-1]!=vec[i].TID) {
              tid_mayor_ceros_empate[cant_elementos_tid_empate_may_cant_ceros]=vec[i].TID;
              cant_elementos_tid_empate_may_cant_ceros++;
          }
        }
      }


///SE HALLAN LA MAYOR CANTIDAD DE 1
      int repetidos_may_cant_unos=0;
      int cant_elementos_tid_empate=0;
      unsigned int tid_mayor_unos_empate[p];
      tid_mayor_unos_empate[cant_elementos_tid_empate]=1;/// se lo inicia con algun valor al azar, para que no tenga TIDs duplicados
      for ( i = 0; i < fi; i++) {
        if (tid_max_unos==vec[i].cantidad_unos_hallados) {
          filas_max_cant_unos[repetidos_may_cant_unos]=i;
          repetidos_may_cant_unos++;
          if (tid_mayor_unos_empate[cant_elementos_tid_empate-1]!=vec[i].TID) {
              tid_mayor_unos_empate[cant_elementos_tid_empate]=vec[i].TID;
              cant_elementos_tid_empate++;
          }
        }
      }

      printf("*La o Las fila/s con mayor cantidad de ceros es/son : ");
      for ( i = 0; i < repetidos_may_cant_ceros; i++) {
        printf("%d ",filas_max_cant_ceros[i]+1 );
      }
      printf("\n");
      printf("*La o Las fila/s con mayor cantidad de unos es/son: ");
      for ( i = 0; i < repetidos_may_cant_unos; i++) {
        printf("%d ",filas_max_cant_unos[i]+1 );
      }
      printf("\n");
      if (repetidos_may_cant_ceros==1) {///No se dio empate
        printf("*El TID del thread que halló la mayor cantidad de ceros es: %u\n",vec[fila_mayor_ceros].TID );
      }
      else { ///Se dio empate

        printf("*Hubo mas de un TID que halló la mayor cantidad de ceros, son:\n");
        for ( i = 0; i < cant_elementos_tid_empate_may_cant_ceros; i++) {
          printf("\t\t\t%u\n",tid_mayor_ceros_empate[i] );
        }
      }




      if (repetidos_may_cant_unos==1) {  ///En este caso no se daria un empate
        printf("*El TID del thread que halló la mayor cantidad de unos es:  %u\n",vec[fila_mayor_unos].TID );

      } else {  /// Se dio un empate entre varios TID

        printf("*Hubo mas de un TID que halló la mayor cantidad de unos, son:\n");
        for ( i = 0; i < cant_elementos_tid_empate; i++) {
          printf("\t\t\t%u\n",tid_mayor_unos_empate[i] );

        }
      }


///SE HALLAN LAS MENORES CANTIDAD DE 0
      int repetidos_men_cant_ceros=0;
      cant_elementos_tid_empate=0;
      unsigned int tid_menor_ceros_empate[p];
      tid_menor_ceros_empate[cant_elementos_tid_empate]=1;/// se lo inicia con algun valor al azar, para que no tenga TIDs duplicados
      for ( i = 0; i < fi; i++) {
        if (tid_min_ceros==vec[i].cantidad_ceros_hallados) {
          repetidos_men_cant_ceros++;
          if (tid_menor_ceros_empate[cant_elementos_tid_empate-1]!=vec[i].TID) {
              tid_menor_ceros_empate[cant_elementos_tid_empate]=vec[i].TID;
              cant_elementos_tid_empate++;
          }
        }
      }
      if (repetidos_men_cant_ceros==1) {///En este caso no se da empate
        printf("*El TID del thread que halló la menor cantidad de ceros es: %u\n",vec[fila_menor_ceros].TID );

      } else {  ///Se dio empate

        printf("*Hubo mas de un TID que halló la menor cantidad de ceros, son:\n");
        for ( i = 0; i < cant_elementos_tid_empate; i++) {
          printf("\t\t\t%u\n",tid_menor_ceros_empate[i] );
        }
      }


///SE HALLAN LA MENOR CANTIDAD DE 1
      int repetidos_men_cant_unos=0;
      cant_elementos_tid_empate=0;
      unsigned int tid_menor_unos_empate[p];
      tid_menor_unos_empate[cant_elementos_tid_empate]=1; /// se lo inicia con algun valor al azar, para que no tenga TIDs duplicados
      for ( i = 0; i < fi; i++) {
        if (tid_min_unos==vec[i].cantidad_unos_hallados) {
          repetidos_men_cant_unos++;
          if (tid_menor_unos_empate[cant_elementos_tid_empate-1]!=vec[i].TID) {
              tid_menor_unos_empate[cant_elementos_tid_empate]=vec[i].TID;
              cant_elementos_tid_empate++;
          }
        }
      }
      if (repetidos_men_cant_unos==1) {///No se dio empate de TIDS
        printf("*El TID del thread que contó la menor cantidad de unos:  %u\n",vec[fila_menor_unos].TID );

      } else { ///No se dio empate

        printf("*Empate en TID con menor cantidad de unos. Ellos son:\n");
        for ( i = 0; i < cant_elementos_tid_empate; i++) {
          printf("\t\t\t%u\n",tid_menor_unos_empate[i] );
        }
      }

//}
  return EXIT_SUCCESS;

}

///Funcion que escribira en los .log la cantidad de 1 y 0 encontrados

void *funcion_thread(void *args){
  FILE * arch = (FILE *) args;
  int i,j;
  t_datos aux;
  char nombre[30];

  unsigned int tid=abs((unsigned int)pthread_self()); ///Se obtiene el TID del thread actual

  snprintf(nombre, 10, "%u", tid);  ///Funcion para convertir de int a array, asi le doy el nombre al .log (Funciona parecido a ITOA)
  strcat(nombre,".log");

/**Se crea y escribe un log con los sig datos:  nº TID, la fila que recorrio,
y la cant de 1 y 0 que encontro en c/fila**/

  FILE *f = fopen(nombre, "wa");
    if (f == NULL){
        printf("Error abriendo archivo!\n");
        exit(1);
    }

    ///Grabo en el .log los 1 y 0 encontrados

    fprintf(f, "TID nº: %u\n", tid);
    fprintf(f, "NºFila      Ceros      Unos\n");
      for ( i = fi_desde; i < fi_hasta; i++) {


        ///SE HALLA LA CANT DE 1 Y 0 POR FILA
        int cant_ceros=0;
        int cant_unos=0;
        for ( j = 0; j < columnas; j++) {
          if (*(mat+i*j+j)==1) {
            cant_unos++;
          }
          if (*(mat+i*j+j)==0) {
            cant_ceros++;
          }
        }
        aux.TID=tid;
        aux.cantidad_ceros_hallados=cant_ceros;
        aux.cantidad_unos_hallados=cant_unos;

        fwrite( &aux, 1, sizeof(t_datos), arch );

        ///ESCRITURA DEL ARCHIVO LOG DE CADA thread
        fprintf(f, "%d              %d        %d\n", i+1,cant_ceros,cant_unos);
        ///FIN
      }
      fclose(f);
    sleep(2);
    return NULL;
}
